
/*``/*                       Minecraft ModPE Script GUI 常用控件测试 V3.0                        *\
```/                                                                                               \
``/                                        by 2639439   - SetTile工作室                             \
`/                                                                                                   \
/                                        内部资料  请不要转载                                         \
\                                                                                                     /
`\         已包含：菜单、弹出式窗口、按钮、文本、文本编辑框、复选框、拖动条、列表选择框              /
``\                                                                                                 /
```\        下一步计划：图片、进度条、星级评分条、画布                                             /
````\*                                                                                           */



var ctx;
var btnWindow=null,mainMenu=null,xyzWindow=null;   //保存菜单的变量




function newLevel()   //进入游戏
{
	try
	{
		ctx = com.mojang.minecraftpe.MainActivity.currentMainActivity.get();   //获取上下文环境
		ctx.runOnUiThread(new java.lang.Runnable(      //运行代码
		{
run: function()
			{
				var layout = new android.widget.LinearLayout(ctx);
				var button = new android.widget.Button(ctx);    //新建按钮1
				button.setText("按钮");    //按钮文字
				button.setTextSize(18);    //文字大小
				button.setTextColor(android.graphics.Color.argb(255,0,100,210));    //文字颜色，四个数字依次为不透明度，红色，绿色，蓝色，最大255，最小0
				button.setOnClickListener(new android.view.View.OnClickListener(
				{
onClick: function(viewarg)      //按下按钮后
					{
						try
						{
							var scroll = new android.widget.ScrollView(ctx);       //新建滚动菜单

							var layout = new android.widget.LinearLayout(ctx);     //新建线性布局
							layout.setOrientation(android.widget.LinearLayout.VERTICAL);    //线性布局VERTICAL为纵向，HORIZONTAL为横向

							var check=false;    //复选框是否被选中


							var title = new android.widget.TextView(ctx);    //新建文本
							title.setTextSize(15);    //文字大小
							title.setTextColor(android.graphics.Color.argb(120,190,235,57));
							//文字颜色，设置为半透明，除了按钮、文本可以设置颜色外，菜单、复选框、文本编辑框也能设置颜色
							title.setText("常用控件、颜色及弹出式窗口的测试");
							layout.addView(title);    //将文字加入线性布局



							var edit1 = new android.widget.EditText(ctx);     //新建文本编辑框
							edit1.setHint("文本编辑框");    //设置提示文字，当文本编辑框为空时显示
							edit1.setText("Hi");         //设置编辑框内文字
							edit1.setInputType(android.text.InputType.TYPE_CLASS_TEXT);  //编辑类型为文字，TYPE_CLASS_TEXT换为TYPE_CLASS_NUMBER则只能编辑数字
							layout.addView(edit1);    //将文本编辑框加入线性布局


							var checkbox1 = new android.widget.CheckBox(ctx);     //新建复选框
							checkbox1.setText("复选框");
							checkbox1.setChecked(false);   //设置为非选中
							checkbox1.setOnCheckedChangeListener(new android.widget.CompoundButton.OnCheckedChangeListener(  //增加选项改变的事件监听器
							{
onCheckedChanged:
								function(v, checked)    //checked为true则是选中，为false非选中
								{
									check=checked;    //保存选中状态
								}
							}));
							layout.addView(checkbox1);    //将复选框加入线性布局


							var btn2 = new android.widget.Button(ctx);    //新建按钮
							btn2.setText("按钮");
							btn2.setOnClickListener(new android.view.View.OnClickListener(   //按钮按下监听器，文本控件也可以设置按下监听器
							{
onClick:
								function(p1)
								{
									print("按下按钮。");
									clientMessage("复选框  ："+check);
									clientMessage("编辑框  ："+edit1.getText());   //获取编辑框内文字
								}
							}));
							layout.addView(btn2);


							var title2 = new android.widget.TextView(ctx);    //新建另一段文本
							title2.setTextSize(12);    //文字大小
							title2.setText("拖动条示例");
							layout.addView(title2);    //将文字加入线性布局


							var seekbar=new android.widget.SeekBar(ctx);       //新建拖动条
							seekbar.setMax(4);         //把拖动条分为4份，加上头尾共有5个拖动的位置，数值分别为0至4
							seekbar.setProgress(2);     //设置拖动到数值为2的地方
							seekbar.setOnSeekBarChangeListener(new android.widget.SeekBar.OnSeekBarChangeListener(   //拖动条事件监听器
							{
onProgressChanged:
								function(s,i,b)    //拖动中数值改变时执行，i为拖动条数值
								{
									title2.setText("    拖动中："+i);    //改变文本内容
								},
onStartTrackingTouch:
								function(s)     //开始拖动时执行
								{
									title2.setText("拖动开始："+seekbar.getProgress());
								},
onStopTrackingTouch:
								function(s)      //结束拖动时执行，可以用getProgress()方法获得拖动条进度(仅限于监听器内部使用)
								{
									title2.setText("拖动结束："+seekbar.getProgress());
								}
							}))
							layout.addView(seekbar);    //将拖动条加入线性布局


							var btn3 = new android.widget.Button(ctx);    //新建打开弹出式窗口的按钮
							btn3.setText("按钮2");
							btn3.setTextColor(android.graphics.Color.argb(255,180,109,251));       //按钮文字颜色
							btn3.setOnClickListener(new android.view.View.OnClickListener(      //按钮按下监听器
							{
onClick:
								function(p1)
								{
									try
									{
										var layout1 = new android.widget.LinearLayout(ctx);     //新建线性布局1
										layout1.setOrientation(android.widget.LinearLayout.VERTICAL);   //布局方式为纵向

										var dialog1 = new android.app.Dialog(ctx);   //新建弹出式窗口
										dialog1.setContentView(layout1);             //设置弹出式窗口内容为线性布局1
										dialog1.setTitle("弹出式窗口及线性布局嵌套");     //设置弹出式窗口标题


										var title3 = new android.widget.TextView(ctx);    //新建文本
										title3.setTextSize(15);
										title3.setText("这是线性布局1，布局方式为纵向，以下一行为线性布局内1的线性布局2，布局方式为横向（点击此文本查看更多信息）。");
										title3.setOnClickListener(new android.view.View.OnClickListener(   //文本按下监听器
										{
onClick:
											function(p1)
											{
												print("\n勾选手机  设置->开发人员选项->显示布局边界  可以查看线性布局的嵌套方式。");
											}
										}));
										layout1.addView(title3);    //将文字加入线性布局1


										var layout2=new android.widget.LinearLayout(ctx);     //新建线性布局2
										layout2.setOrientation(android.widget.LinearLayout.HORIZONTAL);    //布局方式为横向

										var spinner1=new android.widget.Spinner(ctx);      //定义列表选择框(注意：列表选择框仅能在弹出式窗口中使用，菜单使用会崩溃)
										var str=["红石","青金石","黑曜石"];      //列表项
										spinner1.setAdapter(new android.widget.ArrayAdapter(ctx,android.R.layout.simple_spinner_item,str));   //定义列表项，设置适配器
										layout2.addView(spinner1);    //将列表选择框加入线性布局2

										var btn4 = new android.widget.Button(ctx);    //新建按钮
										btn4.setText("确认");
										btn4.setOnClickListener(new android.view.View.OnClickListener()
										{
onClick:
											function(p1)
											{
												print("\n列表选择框：\n选项为："+spinner1.getSelectedItem()+"，\n是第 "+spinner1.getSelectedItemId()+" 个。");
												//获取列表选择框内选项内容及位置
											}
										});
										layout2.addView(btn4);   //将按钮加入线性布局2

										layout1.addView(layout2);    //将线性布局2加入线性布局1


										var btn5 = new android.widget.Button(ctx);    //新建按钮
										btn5.setText("关闭");
										btn5.setOnClickListener(new android.view.View.OnClickListener()
										{
onClick:
											function(p1)
											{
												dialog1.dismiss();    //关闭弹出式窗口
												clientMessage("关闭弹出式窗口。");
											}
										});
										layout1.addView(btn5);    //将按钮加入线性布局1


										dialog1.show();    //显示弹出式窗口
									}
									catch(err)
									{
										    print("打开菜单错误: "+err);
									}
								}
							}));
							layout.addView(btn3);     //将该按钮加入线性布局





							scroll.addView(layout);     //将线性布局加入到滚动菜单中

							var menu = new android.widget.PopupWindow(scroll, dip2px(ctx,120), 400);   //新建菜单
							menu.setContentView(scroll);       //设置菜单内容为该滚动菜单    (这三行语句可以直接在新建菜单方法的参数里写)
							menu.setWidth(dip2px(ctx, 120));   //菜单宽度，120/480=1/4个屏幕宽
							menu.setHeight(400);               //菜单长度，400像素
							menu.setFocusable(true);   //菜单有焦点，即点击菜单以外的地方会关闭菜单
							mainMenu = menu;           //保存菜单变量
							menu.setBackgroundDrawable(new android.graphics.drawable.ColorDrawable(android.graphics.Color.BLACK));
							//菜单颜色黑色(此处的.BLACK可用上面的.argb(255,255,255,255)自定义颜色，其他颜色常量有：灰黑色DKGRAY,灰色GRAY,浅灰色LTGRAY,透明TRANSPARENT,白色WHITE等)
							menu.showAtLocation(ctx.getWindow().getDecorView(), android.view.Gravity.RIGHT | android.view.Gravity.BOTTOM, 30, 40);
						}
						catch(err)
						{
							print("菜单加载失败，因为: "+err);
						}
					}
				}));
				layout.addView(button);


				btnWindow = new android.widget.PopupWindow(layout, dip2px(ctx, 80), dip2px(ctx, 40));   //按钮显示需要新建一个菜单
				btnWindow.setBackgroundDrawable(new android.graphics.drawable.ColorDrawable(android.graphics.Color.TRANSPARENT));     //菜单颜色透明
				btnWindow.showAtLocation(ctx.getWindow().getDecorView(), android.view.Gravity.RIGHT | android.view.Gravity.BOTTOM, 60, 40);
				//菜单显示的位置，这决定了按钮显示的位置(从屏幕右侧到左侧60像素，屏幕底部到顶部40像素，RIGHT和BOTTOM可换为LEFT和TOP)
			}
		}));
	}
	catch(err)     //错误提示
	{
		print("按钮加载失败，因为: "+err);
	}
}

function leaveGame()
{
	try
	{
		ctx.runOnUiThread(new java.lang.Runnable(
		{
run: function()            //回到游戏主菜单后，关闭菜单
			{
				if(btnWindow != null)
				{
					btnWindow.dismiss();
					btnWindow = null;
				}
				if(mainMenu != null)
				{
					mainMenu.dismiss();
					mainMenu = null;
				}

			}
		}));
	}
	catch(err)     //错误提示
	{
		print("菜单关闭失败，因为: "+err);
	}
}



function dip2px(ctx, dips)   //此函数的作用是，把屏幕的几分之几转换为像素，dips=480为屏幕的100%，240为屏幕的50%，以此类推，优点是随着屏幕大小而调节
{
	return Math.ceil(dips * ctx.getResources().getDisplayMetrics().density);
}







