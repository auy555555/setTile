
/*``/*                       Minecraft ModPE Script GUI 常用控件测试 V3.0                        *\
```/                                                                                               \
``/                                        by 2639439   - SetTile工作室                             \
`/                                                                                                   \
/                                        内部资料  请不要转载                                         \
\                                                                                                     /
`\         已包含：菜单、弹出式窗口、按钮、文本、文本编辑框、复选框、拖动条、列表选择框              /
``\                                                                                                 /
```\        下一步计划：图片、进度条、星级评分条、画布                                             /
````\*                                                                                           */



var ctx;
var btnWindow=null,mainMenu=null,xyzWindow=null;




function newLevel()
{
	try
	{
		ctx = com.mojang.minecraftpe.MainActivity.currentMainActivity.get();
		ctx.runOnUiThread(new java.lang.Runnable(
		{
run: function()
			{
				var layout = new android.widget.LinearLayout(ctx);
				var button = new android.widget.Button(ctx);
				button.setText("按钮");
				button.setTextSize(18);
				button.setTextColor(android.graphics.Color.argb(255,0,100,210));
				button.setOnClickListener(new android.view.View.OnClickListener(
				{
onClick: function(viewarg)
					{
						try
						{
							var scroll = new android.widget.ScrollView(ctx);

							var layout = new android.widget.LinearLayout(ctx);
							layout.setOrientation(android.widget.LinearLayout.VERTICAL);

							var check=false;


							var title = new android.widget.TextView(ctx);
							title.setTextSize(15);
							title.setTextColor(android.graphics.Color.argb(120,190,235,57));

							title.setText("常用控件、颜色及弹出式窗口的测试");
							layout.addView(title);



							var edit1 = new android.widget.EditText(ctx);
							edit1.setHint("文本编辑框");
							edit1.setText("Hi");
							edit1.setInputType(android.text.InputType.TYPE_CLASS_TEXT);
							layout.addView(edit1);


							var checkbox1 = new android.widget.CheckBox(ctx);
							checkbox1.setText("复选框");
							checkbox1.setChecked(false);
							checkbox1.setOnCheckedChangeListener(new android.widget.CompoundButton.OnCheckedChangeListener(
							{
onCheckedChanged:
								function(v, checked)
								{
									check=checked;
								}
							}));
							layout.addView(checkbox1);


							var btn2 = new android.widget.Button(ctx);
							btn2.setText("按钮");
							btn2.setOnClickListener(new android.view.View.OnClickListener(
							{
onClick:
								function(p1)
								{
									print("按下按钮。");
									clientMessage("复选框  ："+check);
									clientMessage("编辑框  ："+edit1.getText());
								}
							}));
							layout.addView(btn2);


							var title2 = new android.widget.TextView(ctx);
							title2.setTextSize(12);
							title2.setText("拖动条示例");
							layout.addView(title2);


							var seekbar=new android.widget.SeekBar(ctx);
							seekbar.setMax(4);
							seekbar.setProgress(2);
							seekbar.setOnSeekBarChangeListener(new android.widget.SeekBar.OnSeekBarChangeListener(
							{
onProgressChanged:
								function(s,i,b)
								{
									title2.setText("    拖动中："+i);
								},
onStartTrackingTouch:
								function(s)
								{
									title2.setText("拖动开始："+seekbar.getProgress());
								},
onStopTrackingTouch:
								function(s)
								{
									title2.setText("拖动结束："+seekbar.getProgress());
								}
							}))
							layout.addView(seekbar);


							var btn3 = new android.widget.Button(ctx);
							btn3.setText("按钮2");
							btn3.setTextColor(android.graphics.Color.argb(255,180,109,251));
							btn3.setOnClickListener(new android.view.View.OnClickListener(
							{
onClick:
								function(p1)
								{
									try
									{
										var layout1 = new android.widget.LinearLayout(ctx);
										layout1.setOrientation(android.widget.LinearLayout.VERTICAL);

										var dialog1 = new android.app.Dialog(ctx);
										dialog1.setContentView(layout1);
										dialog1.setTitle("弹出式窗口及线性布局嵌套");


										var title3 = new android.widget.TextView(ctx);
										title3.setTextSize(15);
										title3.setText("这是线性布局1，布局方式为纵向，以下一行为线性布局内1的线性布局2，布局方式为横向（点击此文本查看更多信息）。");
										title3.setOnClickListener(new android.view.View.OnClickListener(
										{
onClick:
											function(p1)
											{
												print("\n勾选手机  设置->开发人员选项->显示布局边界  可以查看线性布局的嵌套方式。");
											}
										}));
										layout1.addView(title3);


										var layout2=new android.widget.LinearLayout(ctx);
										layout2.setOrientation(android.widget.LinearLayout.HORIZONTAL);

										var spinner1=new android.widget.Spinner(ctx);
										var str=["红石","青金石","黑曜石"];
										spinner1.setAdapter(new android.widget.ArrayAdapter(ctx,android.R.layout.simple_spinner_item,str));
										layout2.addView(spinner1);

										var btn4 = new android.widget.Button(ctx);
										btn4.setText("确认");
										btn4.setOnClickListener(new android.view.View.OnClickListener()
										{
onClick:
											function(p1)
											{
												print("\n列表选择框：\n选项为："+spinner1.getSelectedItem()+"，\n是第 "+spinner1.getSelectedItemId()+" 个。");

											}
										});
										layout2.addView(btn4);

										layout1.addView(layout2);


										var btn5 = new android.widget.Button(ctx);
										btn5.setText("关闭");
										btn5.setOnClickListener(new android.view.View.OnClickListener()
										{
onClick:
											function(p1)
											{
												dialog1.dismiss();
												clientMessage("关闭弹出式窗口。");
											}
										});
										layout1.addView(btn5);


										dialog1.show();
									}
									catch(err)
									{
										    print("打开菜单错误: "+err);
									}
								}
							}));
							layout.addView(btn3);





							scroll.addView(layout);

							var menu = new android.widget.PopupWindow(scroll, dip2px(ctx,120), 400);
							menu.setContentView(scroll);
							menu.setWidth(dip2px(ctx, 120));
							menu.setHeight(400);
							menu.setFocusable(true);
							mainMenu = menu;
							menu.setBackgroundDrawable(new android.graphics.drawable.ColorDrawable(android.graphics.Color.BLACK));

							menu.showAtLocation(ctx.getWindow().getDecorView(), android.view.Gravity.RIGHT | android.view.Gravity.BOTTOM, 30, 40);
						}
						catch(err)
						{
							print("菜单加载失败，因为: "+err);
						}
					}
				}));
				layout.addView(button);


				btnWindow = new android.widget.PopupWindow(layout, dip2px(ctx, 80), dip2px(ctx, 40));
				btnWindow.setBackgroundDrawable(new android.graphics.drawable.ColorDrawable(android.graphics.Color.TRANSPARENT));
				btnWindow.showAtLocation(ctx.getWindow().getDecorView(), android.view.Gravity.RIGHT | android.view.Gravity.BOTTOM, 60, 40);

			}
		}));
	}
	catch(err)
	{
		print("按钮加载失败，因为: "+err);
	}
}

function leaveGame()
{
	try
	{
		ctx.runOnUiThread(new java.lang.Runnable(
		{
run: function()
			{
				if(btnWindow != null)
				{
					btnWindow.dismiss();
					btnWindow = null;
				}
				if(mainMenu != null)
				{
					mainMenu.dismiss();
					mainMenu = null;
				}

			}
		}));
	}
	catch(err)
	{
		print("菜单关闭失败，因为: "+err);
	}
}



function dip2px(ctx, dips)
{
	return Math.ceil(dips * ctx.getResources().getDisplayMetrics().density);
}







